plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ayaneooverlay"
    compileSdk = 35

    // Keep Java and Kotlin bytecode targets consistent across JDK installations.
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    defaultConfig {
        applicationId = "com.example.ayaneooverlay"
        minSdk = 26
        targetSdk = 33
        versionCode = 126
        versionName = "0.9.47-expanded-help"
    }
}




